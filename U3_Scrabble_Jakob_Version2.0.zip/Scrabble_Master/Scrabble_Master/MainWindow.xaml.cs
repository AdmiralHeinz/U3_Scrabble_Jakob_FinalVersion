﻿/// Jakob Heinz
/// april 30, 2018
/// scrabble game
/// generate words using 7 given letters.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Scrabble
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> words = new List<string>();/// create a new list for the words
        List<string> letters = new List<string>();/// creates a list for the letters to be used

        public MainWindow()
        {
            InitializeComponent();
            ScrabbleGame sg = new ScrabbleGame();
            char[] lettersArr = sg.drawInitialTiles().ToCharArray();
            
            for (int i = 0; i < 7; i++)
            {
                letters.Add(lettersArr[i].ToString());
                Console.WriteLine(letters[i]);
            }
            ReadFile();
        }

        public void ReadFile()
        {


            System.Windows.Forms.OpenFileDialog openFileDialog = new System.Windows.Forms.OpenFileDialog();/// open file dialog to choose a file
            openFileDialog.ShowDialog();

            System.IO.StreamReader streamReader = new System.IO.StreamReader(openFileDialog.FileName);/// initalize the stream reader to read the choosen file

            while (!streamReader.EndOfStream)/// loop through the txt document
            {

                string word = streamReader.ReadLine();/// read a line of the fiile
                if (CheckWord(word) == true)
                {
                    words.Add(word);///add approved word to the words list
                }
            }

            for (int i = 0; i < words.Count; i++)
            {
                Console.WriteLine(words[i]);/// display list to the console
            }

        }

        public bool CheckWord(string word)
        {
            string alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            for (int i = 0; i < letters.Count; i++)
            {
                alpha = alpha.Replace(letters[i], string.Empty);
            }
            ///MessageBox.Show(alpha);
            char[] alphaArr = alpha.ToCharArray();

            for (int i = 0; i < alphaArr.Length; i++)
            {
                bool contains = word.Contains(alphaArr[i]);
                if (contains == true)
                {
                    return false;
                }
            }
            return true;
        }
    }
}